Udacity Cloud DevOps Nanodegree 
 -Deploy Static Website on AWS

Project url: https://d12xalqz0pt5jj.cloudfront.net/
Project: Lukman Travel Script

In this project, you will deploy a static website to AWS using S3, CloudFront, and IAM.

The files included are: 

index.html - The Index document for the website.
/img - All my image files for the website.
/vendor - Bootssrap CSS framework, Font, and JavaScript libraries needed for the website to function.
/css - CSS files for the website.

images 1-9 are screenshots of my project process


